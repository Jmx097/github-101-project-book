import io
import json
import tempfile
import unittest
import warnings
import zipfile
from pathlib import Path
from unittest.mock import patch
import operator_gate as gate
import workspace

class GateTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.home=self.root/'operator-home'
        self.destination=self.root/'sample-client-folder'
        self.package=self.root/'v0.1.0.zip'
        payload=json.dumps({'client':'Sample client','date':'2026-11-16','status':'Ready','next_step':'Read it','external_send':False},sort_keys=True).encode()
        self.package.write_bytes(workspace.release_bytes('v0.1.0','a'*40,payload))

    def ready(self):
        self.assertTrue(hasattr(gate,'setup'),'The gate needs a real trusted-home setup.')
        gate.setup(self.home,self.destination)

    def approve(self,ttl=3600):
        self.assertTrue(hasattr(gate,'approve'),'Approval must sign the exact release decision.')
        return gate.approve(self.home,self.package,'https://mattermost.example.test/team/pl/samplepost','Learner',ttl)

    def test_no_decision_means_no_client_folder(self):
        self.ready()
        with self.assertRaises(ValueError): gate.deliver(self.home,self.package)
        self.assertFalse(self.destination.exists())

    def test_a_valid_decision_copies_only_sample_output_and_receipt(self):
        self.ready();self.approve();receipt=gate.deliver(self.home,self.package)
        self.assertEqual(set(p.name for p in self.destination.iterdir()),{'client_update.json','receipt.json'})
        self.assertEqual(receipt['source_commit'],'a'*40)
        self.assertEqual(receipt['action'],'copy-client-update')
        self.assertIn('/pl/',receipt['record_url'])
        self.assertFalse((self.destination/'operator_gate.py').exists())

    def test_failed_signing_leaves_no_decision_and_allows_retry(self):
        self.ready()
        key=self.home/'approver/private.pem'
        backup=key.with_suffix('.backup')
        key.rename(backup)
        try:
            with self.assertRaises(ValueError):self.approve()
        finally:
            backup.rename(key)
        self.assertEqual(list((self.home/'approvals').iterdir()),[])
        self.approve()
        gate.deliver(self.home,self.package)
        self.assertTrue((self.destination/'receipt.json').is_file())

    def test_an_expired_decision_is_rejected(self):
        self.ready();record=self.approve(ttl=1)
        with patch.object(gate.time,'time',return_value=record['expires_at']+1):
            with self.assertRaises(ValueError):gate.deliver(self.home,self.package)
        self.assertFalse(self.destination.exists())

    def test_an_edited_decision_fails_signature_verification(self):
        self.ready();record=self.approve();folder=self.home/'approvals'/record['artifact_sha256']
        data=json.loads((folder/'approval.json').read_text());data['expires_at']+=999999
        (folder/'approval.json').write_text(json.dumps(data))
        with self.assertRaises(ValueError):gate.deliver(self.home,self.package)
        self.assertFalse(self.destination.exists())

    def test_changed_package_is_not_covered_by_old_approval(self):
        self.ready();self.approve();self.package.write_bytes(self.package.read_bytes()+b'changed')
        with self.assertRaises(ValueError):gate.deliver(self.home,self.package)
        self.assertFalse(self.destination.exists())

    def test_wrong_destination_is_not_covered(self):
        self.ready();self.approve();p=self.home/'policy.json';policy=json.loads(p.read_text());policy['destination']=str(self.root/'another-folder');p.write_text(json.dumps(policy))
        with self.assertRaises(ValueError):gate.deliver(self.home,self.package)
        self.assertFalse((self.root/'another-folder').exists())

    def test_revocation_stops_the_handoff(self):
        self.ready();self.approve();gate.revoke(self.home,self.package)
        with self.assertRaises(ValueError):gate.deliver(self.home,self.package)
        self.assertFalse(self.destination.exists())

    def test_another_handoff_lock_is_not_removed(self):
        self.ready();self.approve();lock=self.home/'delivery.lock';lock.write_text('another operator')
        with self.assertRaises(ValueError):gate.deliver(self.home,self.package)
        self.assertTrue(lock.exists(),'A refused run must not remove another run’s lock.')
        self.assertEqual(lock.read_text(),'another operator')

    def test_existing_destination_is_not_overwritten(self):
        self.ready();self.approve();self.destination.mkdir();(self.destination/'keep.txt').write_text('Keep this')
        with self.assertRaises(ValueError):gate.deliver(self.home,self.package)
        self.assertEqual((self.destination/'keep.txt').read_text(),'Keep this')
        self.assertFalse((self.destination/'client_update.json').exists())

    def test_destination_created_after_last_check_is_not_replaced(self):
        self.ready();self.approve()
        real_exists=Path.exists
        checks=0
        def competing_create(path):
            nonlocal checks
            value=real_exists(path)
            if path==self.destination:
                checks+=1
                if checks==2 and not value:
                    path.mkdir()
            return value
        with patch.object(Path,'exists',competing_create):
            with self.assertRaises(ValueError):gate.deliver(self.home,self.package)
        self.assertTrue(self.destination.is_dir())
        self.assertEqual(list(self.destination.iterdir()),[])
        self.assertFalse((self.home/'delivery.lock').exists())

    def test_package_with_extra_executable_is_rejected(self):
        self.ready()
        with zipfile.ZipFile(self.package,'a') as z:z.writestr('run.py','print(1)')
        with self.assertRaises(ValueError):self.approve()

    def test_total_expanded_release_size_is_bounded(self):
        raw,manifest,payload=gate.inspect_package(self.package)
        payload+=b' '*180000
        manifest['files']=[{'path':'client_update.json','sha256':gate.digest(payload),'size':len(payload)}]
        manifest_bytes=gate.canonical(manifest)+b' '*30000
        self.assertLess(len(payload),gate.MAX_PACKAGE)
        self.assertLess(len(manifest_bytes),gate.MAX_PACKAGE)
        self.assertGreater(len(payload)+len(manifest_bytes),gate.MAX_PACKAGE)
        with zipfile.ZipFile(self.package,'w',compression=zipfile.ZIP_DEFLATED) as z:
            z.writestr('manifest.json',manifest_bytes)
            z.writestr('client_update.json',payload)
        with self.assertRaises(ValueError):gate.inspect_package(self.package)

    def test_unsafe_zip_member_is_rejected(self):
        self.ready()
        with zipfile.ZipFile(self.package,'a') as z:z.writestr('../outside.txt','No')
        with self.assertRaises(ValueError):self.approve()
        self.assertFalse((self.root/'outside.txt').exists())

    def test_duplicate_zip_member_is_rejected(self):
        self.ready()
        with warnings.catch_warnings():
            warnings.simplefilter('ignore',UserWarning)
            with zipfile.ZipFile(self.package,'a') as z:z.writestr('client_update.json','{}')
        with self.assertRaises(ValueError):self.approve()

    def test_symlinked_destination_parent_is_rejected(self):
        self.ready();self.approve()
        policy_path=self.home/'policy.json';policy=json.loads(policy_path.read_text());original=Path(policy['destination']);parent=original.parent/'link';parent.symlink_to(original.parent,target_is_directory=True);policy['destination']=str(parent/original.name);policy_path.write_text(json.dumps(policy))
        with self.assertRaises(ValueError):gate.deliver(self.home,self.package)
        self.assertFalse(original.exists())
