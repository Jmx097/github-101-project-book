import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

class PlanTests(unittest.TestCase):
    def test_missing_acceptance_stops_the_plan_check(self):
        with tempfile.TemporaryDirectory() as d:
            copy=Path(d)/'workspace'
            shutil.copytree(ROOT,copy,ignore=shutil.ignore_patterns('.git','__pycache__','out'))
            (copy/'change-plan.json').write_text(json.dumps({'change':'Small change','acceptance':[]}))
            r=subprocess.run([sys.executable,'workspace.py','plan'],cwd=copy,capture_output=True,text=True)
            self.assertNotEqual(r.returncode,0,'An incomplete real plan must fail, not print a generic plan.')

if __name__=='__main__':
    unittest.main()
