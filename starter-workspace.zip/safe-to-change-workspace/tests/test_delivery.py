import copy
import json
import unittest
from pathlib import Path
import workspace

ROOT=Path(__file__).resolve().parents[1]
GOOD={'client':'Sample client','date':'2026-11-16','status':'Your first draft is ready to review.','next_step':'Share your notes by Friday.','external_send':False}
CONTRACT={'required_fields':['client','date','status','next_step','external_send'],'allowed_fields':['client','date','status','next_step','external_send'],'output_file':'client_update.json','max_text_length':300,'external_send':False}

class DeliveryTests(unittest.TestCase):
    def test_a_useful_update_keeps_the_agreed_details(self):
        self.assertTrue(hasattr(workspace,'render_update'),'A real update builder is required.')
        result=workspace.render_update(GOOD,CONTRACT)
        self.assertEqual(result,GOOD)

    def test_a_missing_next_step_is_rejected(self):
        self.assertTrue(hasattr(workspace,'render_update'))
        draft=copy.deepcopy(GOOD);draft.pop('next_step')
        with self.assertRaises(ValueError): workspace.render_update(draft,CONTRACT)

    def test_a_private_extra_field_is_rejected(self):
        self.assertTrue(hasattr(workspace,'render_update'))
        draft=copy.deepcopy(GOOD);draft['private_note']='For the team only'
        with self.assertRaises(ValueError): workspace.render_update(draft,CONTRACT)

    def test_external_send_stays_off(self):
        self.assertTrue(hasattr(workspace,'render_update'))
        draft=copy.deepcopy(GOOD);draft['external_send']=True
        with self.assertRaises(ValueError): workspace.render_update(draft,CONTRACT)

    def test_the_current_draft_meets_the_delivery_promise(self):
        self.assertTrue(hasattr(workspace,'render_update'))
        draft=json.loads((ROOT/'draft.json').read_text())
        contract=json.loads((ROOT/'delivery-contract.json').read_text())
        self.assertEqual(workspace.render_update(draft,contract)['client'],'Sample client')
