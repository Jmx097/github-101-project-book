import io
import json
import unittest
import zipfile
import workspace

class ReleaseTests(unittest.TestCase):
    def test_release_bytes_are_repeatable_and_contain_only_the_sample_output(self):
        self.assertTrue(hasattr(workspace,'release_bytes'),'Create a real repeatable release package.')
        payload=json.dumps({'client':'Sample client','date':'2026-11-16','status':'Ready','next_step':'Read it','external_send':False},sort_keys=True).encode()
        a=workspace.release_bytes('v0.1.0','a'*40,payload)
        b=workspace.release_bytes('v0.1.0','a'*40,payload)
        self.assertEqual(a,b)
        with zipfile.ZipFile(io.BytesIO(a)) as z:
            self.assertEqual(set(z.namelist()),{'manifest.json','client_update.json'})
            m=json.loads(z.read('manifest.json'))
            self.assertEqual(m['source_commit'],'a'*40)
            self.assertEqual(m['version'],'v0.1.0')
