import subprocess
import tempfile
import unittest
from pathlib import Path
import workspace

class SecretTests(unittest.TestCase):
    def test_supported_marker_is_detected_without_echoing_its_value(self):
        self.assertTrue(hasattr(workspace,'scan_text'))
        token='COURSE_'+'SECRET_'+'HARMLESSEXAMPLE123'
        result=workspace.scan_text('note='+token,'sample.txt')
        self.assertTrue(result)
        self.assertNotIn(token,str(result))

    def test_a_supported_token_is_detected(self):
        self.assertTrue(hasattr(workspace,'scan_text'))
        self.assertTrue(workspace.scan_text('gh'+'p_'+'a'*36,'sample.txt'))

    def test_untracked_sample_marker_is_scanned(self):
        self.assertTrue(hasattr(workspace,'scan_tree'))
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);(root/'.demo-secret.txt').write_text('COURSE_'+'SECRET_'+'HARMLESSEXAMPLE123')
            self.assertTrue(workspace.scan_tree(root))

    def test_a_marker_removed_in_a_later_commit_is_still_detected(self):
        self.assertTrue(hasattr(workspace,'scan_tree'))
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            def git(*args):
                r=subprocess.run(['git','-c','user.name=Course Test','-c','user.email=test@example.invalid',*args],cwd=root,capture_output=True,text=True)
                self.assertEqual(r.returncode,0,r.stderr)
                return r.stdout.strip()
            git('init','-b','main');(root/'readme.txt').write_text('safe')
            git('add','.');git('commit','-m','baseline');base=git('rev-parse','HEAD')
            (root/'note.txt').write_text('COURSE_'+'SECRET_'+'HARMLESSEXAMPLE123');git('add','.');git('commit','-m','sample finding')
            (root/'note.txt').unlink();git('add','-A');git('commit','-m','remove it')
            self.assertTrue(workspace.scan_tree(root,base))

    def test_clean_text_passes(self):
        self.assertTrue(hasattr(workspace,'scan_text'))
        self.assertEqual(workspace.scan_text('A normal sample update.','sample.txt'),[])
