# Safe to change — starter workspace

Build a small project you can check, review, release and hand off with a clear decision.

Open **START-HERE.md** for all eight lessons. It covers the local exercises, GitHub’s required checks, a versioned release, a Mattermost review and the separate client-folder gate.

## Begin on your computer

Use Python 3.11 or newer, Git and OpenSSL 3. On macOS/Linux use `python3`; on Windows use `python` or your configured `py -3` launcher.

From this folder:

```text
python3 workspace.py doctor
python3 workspace.py check
```

The complete check reads `change-plan.json`, runs the tests and scans the sample source. It ends with `CHECKS PASS` when those checks pass.

## Try a real failure

These commands change the included sample files. They do not print a pretend test result.

```text
python3 workspace.py demo-broken
python3 workspace.py test
python3 workspace.py reset --yes
python3 workspace.py check

python3 workspace.py demo-secret
python3 workspace.py scan
python3 workspace.py reset --yes
python3 workspace.py scan
```

The missing next step makes the current-draft test fail. The harmless course marker makes the secret scan fail without printing its value. Reset restores the included draft, so keep any wording you want before running it.

The scanner covers the course marker, common GitHub token patterns, AWS access-key IDs and private-key headers. It is a teaching scanner with a declared scope, not a promise to find every credential or private fact. The GitHub workflow also scans newly introduced history. Revoke or rotate a real exposed key; deleting its latest visible line is not enough.

## Release only saved source

Initialize and commit the sample as explained in START-HERE.md. After a passing, reviewed merge to `main`, keep the source clean and run:

```text
python3 workspace.py package
```

`VERSION` holds the name, initially `v0.1.0`. The command runs the checks again and creates `out/v0.1.0.zip` and `out/v0.1.0.sha256`. The ZIP contains only `client_update.json` and a manifest with the version, full source commit and output fingerprint. It does not include source code, approval keys or runtime state. New work gets a new version; existing packages are not replaced.

## Make the repository rules real

The included `.github/workflows/ci.yml` runs three jobs named exactly `plan`, `tests` and `secrets`. Workflow permissions are read-only. The official GitHub actions are pinned to exact commits.

On your own sample repository, run the first workflow, then make all three checks required in an **active** rule for `main`, require a pull request and an up-to-date branch, and leave the bypass list empty. Creating the YAML file alone does not block merges. A solo learner can prove the automated check gate with required approvals at 0. Require an authorized teammate’s review when you have one; you cannot approve your own PR.

Treat edits to the scanner, workflow, tests and delivery promise as important review work. A person who can weaken those files or change repository rules can change what the checks mean.

## Keep permission separate

Follow the full guide before running setup, approval or delivery. Use only new sample folders beside this source folder.

```text
python3 operator_gate.py setup --home ../operator-home --destination ../sample-client-folder
python3 ../operator-home/operator_gate.py deliver --home ../operator-home --package out/v0.1.0.zip
```

The unsigned attempt must stop. Setup installs a separate operator copy and makes an Ed25519 approval key under `../operator-home/approver/private.pem`. Never put that key in GitHub, Mattermost, the source folder or a client folder.

Generate and review a request for your actual GitHub release, then post it in an authorized Mattermost channel. The named approver checks the release, passing checks, fingerprint, action, destination and expiry. Only that authorized key holder signs the resulting decision. Replace every placeholder below before running it:

```text
python3 ../operator-home/operator_gate.py approve --home ../operator-home --package out/v0.1.0.zip --post-url https://YOUR-MATTERMOST-SITE/YOUR-TEAM/pl/YOUR-DECISION-POST --approver "YOUR NAME" --expires-in 3600
python3 ../operator-home/operator_gate.py deliver --home ../operator-home --package out/v0.1.0.zip
```

The gate checks the exact package fingerprint, source commit, version, signed action, configured destination, expiry and hold state. It copies only the sample JSON output and a receipt. It never executes source from the ZIP or overwrites an existing destination. It does not send a message or activate a client system.

Use a parent folder that only the operator can change. A stopped copy can leave an incomplete sample destination; the operator must inspect it before recovery. Do not delete working client files to make a retry pass. This is not an all-or-nothing filesystem transaction.

The Mattermost permalink is a reference. The key holder must verify the actual human decision; the tool does not log in to Mattermost or verify the post author. A reaction or chat post alone does not unlock delivery.

One learner can play both roles for this local exercise. Real use requires protected, separately owned approver/operator accounts, a trusted installed gate and policy, and an operator service that does not accept an arbitrary caller-selected trust home. This sample does not create that operating-system separation.

After the successful lesson, a hold blocks later attempts without deleting what was already delivered:

```text
python3 ../operator-home/operator_gate.py revoke --home ../operator-home --package out/v0.1.0.zip
```

## Files

- `draft.json`: the sample update you change.
- `change-plan.json`: the intended change and review questions.
- `delivery-contract.json`: required and allowed output details.
- `sample/default-draft.json`: the reset copy.
- `tests/`: repeatable checks, including signed-gate refusal cases.
- `workspace.py`: local checks, real failure exercises and release packaging.
- `operator_gate.py`: the installable, separate sample handoff tool.
- `.github/workflows/ci.yml`: plan, tests and secrets on push/pull request.
- `.github/PULL_REQUEST_TEMPLATE.md`: a short review prompt.
- `START-HERE.md`: the full self-paced guide.

Keep generated output under `out`, and operator keys/state outside the source. Use sample files only in a public learning repository. For real work, match the contract, tests, secret scanning, membership and permissions to the actual client and job first.
