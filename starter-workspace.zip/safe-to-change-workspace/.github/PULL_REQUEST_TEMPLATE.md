## What changes?

Write one short sentence about the useful change.

## What stays true?

- The agreed client, date, status and next step remain useful.
- External sending stays off.
- No private notes or credentials enter the sample output or source.

## What did you check?

- [ ] The plan describes this change and its limits.
- [ ] The real tests pass on this version.
- [ ] The supported secret scan passes, including new history on GitHub.
- [ ] I read the actual changed files, especially any workflow, scanner, test or contract edits.

Link the checks. Name the return point. A merge is not permission for a client-folder handoff; that remains a separate decision for an exact release.
