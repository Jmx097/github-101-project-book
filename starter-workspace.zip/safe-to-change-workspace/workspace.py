#!/usr/bin/env python3
"""Local commands for the Safe to change learning workspace."""
import argparse
import hashlib
import io
import zipfile
import json
import re
import subprocess
import sys
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parent


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def validate_plan(root=ROOT):
    plan = read_json(root / 'change-plan.json')
    for key in ('change', 'why', 'rollback'):
        if not isinstance(plan.get(key), str) or not plan[key].strip():
            raise ValueError('The plan needs a clear ' + key + '.')
    for key in ('acceptance', 'allowed_paths', 'out_of_scope'):
        items = plan.get(key)
        if not isinstance(items, list) or not items or any(not isinstance(x, str) or not x.strip() for x in items):
            raise ValueError('The plan needs at least one ' + key + ' item.')
    for item in plan['allowed_paths']:
        p = PurePosixPath(item)
        if p.is_absolute() or '..' in p.parts or '\\' in item or ':' in item or item.startswith('.git'):
            raise ValueError('Use safe relative paths in allowed_paths.')
    return plan


def render_update(draft, contract):
    from datetime import date
    if not isinstance(draft, dict) or not isinstance(contract, dict):
        raise ValueError('Use JSON objects for the update and contract.')
    required = contract['required_fields']
    allowed = contract['allowed_fields']
    if not isinstance(required, list) or not isinstance(allowed, list) or not set(required) <= set(allowed):
        raise ValueError('The delivery contract has invalid fields.')
    missing = set(required) - set(draft)
    extra = set(draft) - set(allowed)
    if missing:
        raise ValueError('Missing agreed detail: ' + ', '.join(sorted(missing)))
    if extra:
        raise ValueError('Unexpected detail: ' + ', '.join(sorted(extra)))
    if contract.get('external_send') is not False or draft.get('external_send') is not False:
        raise ValueError('External sending must stay off.')
    for field in ('client', 'date', 'status', 'next_step'):
        value = draft.get(field)
        if not isinstance(value, str) or not value.strip() or len(value) > contract.get('max_text_length', 300):
            raise ValueError('Use a short, nonempty ' + field + '.')
    date.fromisoformat(draft['date'])
    if contract.get('output_file') != 'client_update.json':
        raise ValueError('The sample output must stay client_update.json.')
    return dict(draft)


def cmd_test(args):
    import subprocess
    return subprocess.run([sys.executable, '-m', 'unittest', 'discover', '-s', 'tests', '-v'], cwd=ROOT).returncode


PATTERNS = [
    ('course marker', re.compile(r'COURSE_SECRET_[A-Z0-9]{8,}')),
    ('GitHub access token', re.compile(r'gh[pousr]_[A-Za-z0-9_]{20,}|github_pat_[A-Za-z0-9_]{30,}')),
    ('AWS access key', re.compile(r'AKIA[0-9A-Z]{16}')),
    ('private key', re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----')),
]
SKIP_DIRS = {'.git', '__pycache__', 'out', '.venv', 'venv'}


def scan_text(text, name):
    findings = []
    for label, pattern in PATTERNS:
        for match in pattern.finditer(text):
            findings.append({'file': str(name), 'line': text.count('\n', 0, match.start()) + 1, 'kind': label})
    return findings


def scan_tree(root=ROOT, base=None):
    findings = []
    for path in sorted(root.rglob('*')):
        rel = path.relative_to(root)
        if any(part in SKIP_DIRS for part in rel.parts) or not path.is_file():
            continue
        if path.is_symlink():
            raise ValueError('Remove the source symlink before scanning: ' + str(rel))
        if path.stat().st_size > 2_000_000:
            raise ValueError('A source file is too large for this course scan: ' + str(rel))
        raw = path.read_bytes()
        if b'\0' in raw:
            raise ValueError('Remove binary files from this sample source: ' + str(rel))
        findings.extend(scan_text(raw.decode('utf-8', errors='replace'), rel))
    if base and set(base) != {'0'}:
        if not re.fullmatch(r'[0-9a-fA-F]{40}', base):
            raise ValueError('The comparison commit must be a full Git commit ID.')
        result = subprocess.run(['git', 'log', '--format=', '--no-color', '--no-ext-diff', '-p', base + '..HEAD', '--', '.'], cwd=root, capture_output=True, text=True)
        if result.returncode:
            raise ValueError('Cannot scan the comparison history. Fetch the base commit and try again.')
        findings.extend(scan_text(result.stdout, 'new commit history'))
    return findings


def cmd_scan(args):
    findings = scan_tree(base=args.base)
    if findings:
        for item in findings:
            print('SECRET STOP: {file}:{line} ({kind}); value hidden'.format(**item))
        return 1
    print('SECRETS PASS: no supported pattern was found in the scanned files' + (' and new commit history.' if args.base and set(args.base) != {'0'} else '.'))
    return 0


def cmd_plan(args):
    validate_plan()
    print('PLAN PASS: the change, limits and acceptance checks are written down.')
    return 0


def release_bytes(version, commit, payload):
    if not re.fullmatch(r'v[0-9]+\.[0-9]+\.[0-9]+', version) or not re.fullmatch(r'[0-9a-f]{40}', commit):
        raise ValueError('Use a version like v0.1.0 and a full source commit.')
    manifest = {'schema': 1, 'version': version, 'source_commit': commit,
                'files': [{'path': 'client_update.json', 'sha256': hashlib.sha256(payload).hexdigest(), 'size': len(payload)}]}
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, 'w', zipfile.ZIP_DEFLATED) as archive:
        for name, content in [('client_update.json', payload), ('manifest.json', (json.dumps(manifest, sort_keys=True, indent=2) + '\n').encode())]:
            info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
            info.external_attr = 0o100644 << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, content)
    return stream.getvalue()


def git(root, *args):
    result = subprocess.run(['git', *args], cwd=root, capture_output=True, text=True)
    if result.returncode:
        raise ValueError('Git could not complete this step. ' + result.stderr.strip())
    return result.stdout.strip()


def cmd_doctor(args):
    if sys.version_info < (3, 11):
        raise ValueError('Install Python 3.11 or newer.')
    print('Python ' + sys.version.split()[0])
    for tool in ('git', 'openssl'):
        result = subprocess.run([tool, '--version' if tool == 'git' else 'version'], capture_output=True, text=True)
        if result.returncode:
            raise ValueError('Check your ' + tool + ' installation.')
        if tool == 'openssl' and not result.stdout.startswith('OpenSSL 3.'):
            raise ValueError('This guide uses OpenSSL 3 for approval signatures.')
        print(result.stdout.strip())
    print('TOOLS READY')
    return 0


def cmd_check(args):
    cmd_plan(args)
    code = cmd_test(args)
    if code:
        return code
    code = cmd_scan(argparse.Namespace(base=getattr(args, 'base', None)))
    if code:
        return code
    render_update(read_json(ROOT / 'draft.json'), read_json(ROOT / 'delivery-contract.json'))
    print('CHECKS PASS: plan, tests and supported secret checks.')
    return 0


def cmd_demo_broken(args):
    path = ROOT / 'draft.json'
    if path.is_symlink():
        raise ValueError('Remove the sample-file symlink first.')
    draft = read_json(path)
    draft.pop('next_step', None)
    path.write_text(json.dumps(draft, indent=2) + '\n', encoding='utf-8')
    print('Changed draft.json: the next_step is now missing. Run test to see the failure.')
    return 0


def cmd_demo_secret(args):
    path = ROOT / '.demo-secret.txt'
    if path.exists() or path.is_symlink():
        raise ValueError('The sample marker already exists. Reset the sample first.')
    path.write_text('COURSE_' + 'SECRET_' + 'HARMLESSEXAMPLE123' + '\n', encoding='utf-8')
    print('Added a harmless course marker in .demo-secret.txt. Run scan to check it.')
    return 0


def cmd_reset(args):
    if not args.yes:
        raise ValueError('reset --yes replaces draft.json with the included sample and removes only the course marker.')
    target = ROOT / 'draft.json'
    marker = ROOT / '.demo-secret.txt'
    if target.is_symlink() or marker.is_symlink():
        raise ValueError('Remove the sample-file symlink first.')
    target.write_bytes((ROOT / 'sample' / 'default-draft.json').read_bytes())
    if marker.exists():
        marker.unlink()
    print('SAMPLE RESET: draft.json restored and the course marker removed.')
    return 0


def cmd_package(args):
    commit = git(ROOT, 'rev-parse', 'HEAD')
    if git(ROOT, 'status', '--porcelain'):
        raise ValueError('Save the reviewed source in a clean Git commit before packaging.')
    if cmd_check(argparse.Namespace(base=None)):
        return 1
    version = (ROOT / 'VERSION').read_text().strip()
    update = render_update(read_json(ROOT / 'draft.json'), read_json(ROOT / 'delivery-contract.json'))
    payload = (json.dumps(update, sort_keys=True, indent=2) + '\n').encode('utf-8')
    content = release_bytes(version, commit, payload)
    out = ROOT / 'out'
    out.mkdir(exist_ok=True)
    path = out / (version + '.zip')
    if path.exists():
        raise ValueError('That version is already packaged. Use a new version for new work.')
    path.write_bytes(content)
    digest = hashlib.sha256(content).hexdigest()
    (out / (version + '.sha256')).write_text(digest + '  ' + path.name + '\n')
    print('RELEASE READY: out/' + path.name)
    print('SHA256 ' + digest)
    print('SOURCE ' + commit)
    return 0


def cmd_request(args):
    from urllib.parse import urlparse
    version = (ROOT / 'VERSION').read_text().strip()
    package = ROOT / 'out' / (version + '.zip')
    if not package.is_file():
        raise ValueError('Package the reviewed version first.')
    url = urlparse(args.release_url)
    if url.scheme != 'https' or url.hostname != 'github.com' or '/releases/' not in url.path:
        raise ValueError('Use the HTTPS link to your actual GitHub release.')
    with zipfile.ZipFile(package) as archive:
        manifest = json.loads(archive.read('manifest.json'))
    destination = str(Path(args.destination).resolve())
    digest = hashlib.sha256(package.read_bytes()).hexdigest()
    text = ('## Release ready for review\n\n'
            'Release: ' + args.release_url + '\n'
            'Version: ' + manifest['version'] + '\n'
            'Source commit: ' + manifest['source_commit'] + '\n'
            'Package SHA256: ' + digest + '\n'
            'Requested action: copy-client-update\n'
            'Destination: ' + destination + '\n'
            'Local package checks: plan, tests and supported secret scan passed before packaging.\n'
            'GitHub checks: add the link to the passing run for this source commit.\n'
            'Approver: add the named person who can allow this handoff.\n'
            'Decision: waiting for a human review.\n'
            'Return point: record the earlier approved version, if one exists.\n\n'
            'Please review this exact release, destination and action. Reply in this thread; keep approval keys out of chat.\n')
    (ROOT / 'out' / 'release-request.md').write_text(text, encoding='utf-8')
    print('REQUEST READY: out/release-request.md. Review it before posting it in your authorized Mattermost channel.')
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('plan').set_defaults(fn=cmd_plan)
    commands.add_parser('test').set_defaults(fn=cmd_test)
    commands.add_parser('doctor').set_defaults(fn=cmd_doctor)
    commands.add_parser('demo-broken').set_defaults(fn=cmd_demo_broken)
    commands.add_parser('demo-secret').set_defaults(fn=cmd_demo_secret)
    commands.add_parser('package').set_defaults(fn=cmd_package)
    reset = commands.add_parser('reset')
    reset.add_argument('--yes', action='store_true')
    reset.set_defaults(fn=cmd_reset)
    check = commands.add_parser('check')
    check.add_argument('--base', default=None)
    check.set_defaults(fn=cmd_check)
    request = commands.add_parser('request')
    request.add_argument('--destination', required=True)
    request.add_argument('--release-url', required=True)
    request.set_defaults(fn=cmd_request)
    scan = commands.add_parser('scan')
    scan.add_argument('--base', default=None)
    scan.set_defaults(fn=cmd_scan)
    args = parser.parse_args()
    try:
        return args.fn(args)
    except (ValueError, OSError, KeyError, json.JSONDecodeError) as exc:
        print('STOP: ' + str(exc), file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
