#!/usr/bin/env python3
"""Check a signed decision before copying a sample client update."""
import argparse
import hashlib
import io
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import zipfile
from datetime import date
from pathlib import Path
from urllib.parse import urlparse

ACTION = 'copy-client-update'
MAX_PACKAGE = 200_000
ALLOWED = {'manifest.json', 'client_update.json'}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def canonical(data):
    return (json.dumps(data, sort_keys=True, indent=2) + '\n').encode('utf-8')


def no_symlinks(path):
    path = Path(os.path.abspath(path))
    for part in [path, *path.parents]:
        if part.is_symlink():
            raise ValueError('A trusted path must not pass through a symlink.')
    return path


def unique_json(data):
    def unique(pairs):
        obj = {}
        for key, value in pairs:
            if key in obj:
                raise ValueError('Duplicate JSON fields are not allowed.')
            obj[key] = value
        return obj
    return json.loads(data, object_pairs_hook=unique)


def openssl(*args):
    result = subprocess.run(['openssl', *map(str, args)], capture_output=True, text=True)
    if result.returncode:
        raise ValueError('The signature check did not pass, or OpenSSL could not complete the step.')
    return result


def inspect_package(package):
    package = no_symlinks(package)
    if not package.is_file() or package.stat().st_size > MAX_PACKAGE:
        raise ValueError('Use a small, regular release ZIP from this workspace.')
    raw = package.read_bytes()
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        infos = archive.infolist()
        names = [info.filename for info in infos]
        if len(names) != len(set(names)) or set(names) != ALLOWED:
            raise ValueError('The release must contain only manifest.json and client_update.json, once each.')
        if sum(info.file_size for info in infos) > MAX_PACKAGE:
            raise ValueError('The total expanded release is too large.')
        for info in infos:
            mode = info.external_attr >> 16
            if stat.S_ISLNK(mode) or info.file_size > MAX_PACKAGE or info.flag_bits & 1:
                raise ValueError('Encrypted, oversized or symlinked release members are not allowed.')
        manifest = unique_json(archive.read('manifest.json'))
        payload = archive.read('client_update.json')
    if set(manifest) != {'schema', 'version', 'source_commit', 'files'} or manifest['schema'] != 1:
        raise ValueError('The release manifest format is not supported.')
    if not re.fullmatch(r'v[0-9]+\.[0-9]+\.[0-9]+', manifest['version']):
        raise ValueError('The release needs a version name.')
    if not re.fullmatch(r'[0-9a-f]{40}', manifest['source_commit']):
        raise ValueError('The release needs its exact source commit.')
    files = manifest['files']
    expected = {'path': 'client_update.json', 'sha256': digest(payload), 'size': len(payload)}
    if files != [expected]:
        raise ValueError('The output does not match the manifest fingerprint.')
    update = unique_json(payload)
    if set(update) != {'client', 'date', 'status', 'next_step', 'external_send'}:
        raise ValueError('The client update has missing or unexpected fields.')
    if update['external_send'] is not False:
        raise ValueError('The sample must not enable external sending.')
    for field in ('client', 'date', 'status', 'next_step'):
        if not isinstance(update[field], str) or not update[field].strip() or len(update[field]) > 300:
            raise ValueError('The client update has an invalid ' + field + '.')
    date.fromisoformat(update['date'])
    return raw, manifest, payload


def setup(home, destination):
    home = no_symlinks(home)
    destination = no_symlinks(destination)
    source = Path(__file__).resolve().parent
    if home == source or source in home.parents:
        raise ValueError('Keep the operator home outside the source workspace.')
    if home.exists():
        raise ValueError('That operator home already exists. Do not replace its trust settings.')
    if destination == home or home in destination.parents or destination in home.parents:
        raise ValueError('Keep the sample client folder separate from the operator home.')
    if destination == source or source in destination.parents:
        raise ValueError('Keep the sample client folder outside the source workspace.')
    home.mkdir(parents=True, mode=0o700)
    home.chmod(0o700)
    (home / 'approver').mkdir(mode=0o700)
    (home / 'approvals').mkdir(mode=0o700)
    key = home / 'approver' / 'private.pem'
    key.touch(mode=0o600, exist_ok=False)
    openssl('genpkey', '-algorithm', 'ED25519', '-out', key)
    key.chmod(0o600)
    public = home / 'trusted-public.pem'
    openssl('pkey', '-in', key, '-pubout', '-out', public)
    public.chmod(0o600)
    policy = {'schema': 1, 'action': ACTION, 'destination': str(destination), 'public_key_sha256': digest(public.read_bytes())}
    (home / 'policy.json').write_bytes(canonical(policy))
    (home / 'policy.json').chmod(0o600)
    shutil.copyfile(__file__, home / 'operator_gate.py')
    return policy


def load_policy(home):
    home = no_symlinks(home)
    policy = unique_json((home / 'policy.json').read_bytes())
    public = no_symlinks(home / 'trusted-public.pem')
    if policy.get('schema') != 1 or policy.get('action') != ACTION:
        raise ValueError('The trusted policy does not allow this action.')
    if digest(public.read_bytes()) != policy.get('public_key_sha256'):
        raise ValueError('The trusted public key has changed.')
    no_symlinks(policy['destination'])
    return policy


def approve(home, package, record_url, approver, ttl=3600):
    home = no_symlinks(home)
    policy = load_policy(home)
    raw, manifest, payload = inspect_package(package)
    url = urlparse(record_url)
    if url.scheme != 'https' or not url.hostname or '/pl/' not in url.path:
        raise ValueError('Copy the HTTPS permalink of the actual Mattermost decision post.')
    if not isinstance(approver, str) or not approver.strip() or len(approver) > 100:
        raise ValueError('Name the person making the decision.')
    if not isinstance(ttl, int) or not 1 <= ttl <= 86400:
        raise ValueError('Approval must expire within one day.')
    package_sha = digest(raw)
    folder = home / 'approvals' / package_sha
    if folder.exists():
        raise ValueError('A decision already exists for this package. Keep its history; make a new release for new work.')
    now = int(time.time())
    record = {'schema': 1, 'artifact_sha256': package_sha, 'version': manifest['version'],
              'source_commit': manifest['source_commit'], 'destination': policy['destination'],
              'action': ACTION, 'approved_at': now, 'expires_at': now + ttl,
              'approver': approver.strip(), 'record_url': record_url}
    with tempfile.TemporaryDirectory(prefix='.pending-decision-', dir=home / 'approvals') as pending:
        staged = Path(pending)
        decision = staged / 'approval.json'
        decision.write_bytes(canonical(record))
        key = no_symlinks(home / 'approver' / 'private.pem')
        openssl('pkeyutl', '-sign', '-rawin', '-inkey', key, '-in', decision, '-out', staged / 'approval.sig')
        # Reserve only after signing succeeds; never replace a competing decision.
        folder.mkdir(mode=0o700)
        try:
            for name in ('approval.json', 'approval.sig'):
                with (folder / name).open('xb') as target:
                    target.write((staged / name).read_bytes())
        except BaseException:
            shutil.rmtree(folder)
            raise
    return record


def revoke(home, package):
    load_policy(home)
    raw, manifest, payload = inspect_package(package)
    folder = no_symlinks(Path(home) / 'approvals' / digest(raw))
    if not folder.is_dir():
        raise ValueError('There is no approval to put on hold.')
    marker = folder / 'revoked.json'
    if marker.exists():
        raise ValueError('This approval is already on hold.')
    marker.write_bytes(canonical({'revoked_at': int(time.time()), 'action': ACTION}))
    return marker


def deliver(home, package):
    home = no_symlinks(home)
    policy = load_policy(home)
    raw, manifest, payload = inspect_package(package)
    package_sha = digest(raw)
    folder = no_symlinks(home / 'approvals' / package_sha)
    if not folder.is_dir() or not (folder / 'approval.json').is_file() or not (folder / 'approval.sig').is_file():
        raise ValueError('No signed approval exists for this exact release.')
    if (folder / 'revoked.json').exists():
        raise ValueError('This approval is on hold.')
    decision = no_symlinks(folder / 'approval.json')
    signature = no_symlinks(folder / 'approval.sig')
    openssl('pkeyutl', '-verify', '-rawin', '-pubin', '-inkey', home / 'trusted-public.pem', '-in', decision, '-sigfile', signature)
    record = unique_json(decision.read_bytes())
    required = {'schema', 'artifact_sha256', 'version', 'source_commit', 'destination', 'action', 'approved_at', 'expires_at', 'approver', 'record_url'}
    if set(record) != required or record['schema'] != 1:
        raise ValueError('The approval format is not supported.')
    expected = {'artifact_sha256': package_sha, 'version': manifest['version'], 'source_commit': manifest['source_commit'], 'destination': policy['destination'], 'action': ACTION}
    if any(record[key] != value for key, value in expected.items()):
        raise ValueError('The approval does not match this release, action or destination.')
    now = time.time()
    if not isinstance(record['approved_at'], int) or not isinstance(record['expires_at'], int) or record['approved_at'] > now + 30 or record['expires_at'] <= now:
        raise ValueError('This approval is expired or not yet valid.')
    destination = no_symlinks(policy['destination'])
    if destination.exists():
        raise ValueError('The destination already exists. This gate never overwrites a client folder.')
    if not destination.parent.is_dir():
        raise ValueError('Create the intended sample parent folder first.')
    receipt = dict(record)
    receipt['delivered_at'] = int(now)
    receipt['files'] = manifest['files']
    lock = home / 'delivery.lock'
    own_lock = False
    try:
        with lock.open('x') as handle:
            own_lock = True
            handle.write(str(os.getpid()))
        staging = Path(tempfile.mkdtemp(prefix='.sample-handoff-', dir=destination.parent))
        try:
            (staging / 'client_update.json').write_bytes(payload)
            (staging / 'receipt.json').write_bytes(canonical(receipt))
            if destination.exists() or destination.is_symlink():
                raise ValueError('The destination appeared during the check. Nothing was replaced.')
            no_symlinks(destination.parent)
            # mkdir is an exclusive reservation: unlike POSIX rename, it cannot
            # replace an empty directory created after the last existence check.
            destination.mkdir(mode=0o700)
            for name in ('client_update.json', 'receipt.json'):
                with (destination / name).open('xb') as target:
                    target.write((staging / name).read_bytes())
        finally:
            if staging.exists():
                shutil.rmtree(staging)
    except FileExistsError as exc:
        raise ValueError('Another handoff is in progress. Check the operator state before retrying.') from exc
    finally:
        if own_lock and lock.exists():
            lock.unlink()
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    init = commands.add_parser('setup')
    init.add_argument('--home', required=True)
    init.add_argument('--destination', required=True)
    for command in ('approve', 'deliver', 'revoke'):
        cmd = commands.add_parser(command)
        cmd.add_argument('--home', required=True)
        cmd.add_argument('--package', required=True)
        if command == 'approve':
            cmd.add_argument('--post-url', required=True)
            cmd.add_argument('--approver', required=True)
            cmd.add_argument('--expires-in', type=int, default=3600)
    args = parser.parse_args()
    try:
        if args.command == 'setup':
            setup(args.home, args.destination)
            print('OPERATOR HOME READY: ' + str(Path(args.home).resolve()))
            print('Keep approver/private.pem outside GitHub, Mattermost and downloads.')
        elif args.command == 'approve':
            record = approve(args.home, args.package, args.post_url, args.approver, args.expires_in)
            print('APPROVAL SIGNED for ' + record['version'] + ' / ' + record['artifact_sha256'])
        elif args.command == 'revoke':
            revoke(args.home, args.package)
            print('APPROVAL ON HOLD: future handoff attempts are blocked.')
        else:
            receipt = deliver(args.home, args.package)
            print('HANDOFF ALLOWED: ' + receipt['destination'])
            print('RECEIPT: ' + str(Path(receipt['destination']) / 'receipt.json'))
        return 0
    except (ValueError, OSError, KeyError, TypeError, json.JSONDecodeError, zipfile.BadZipFile) as exc:
        print('HANDOFF STOP: ' + str(exc), file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
